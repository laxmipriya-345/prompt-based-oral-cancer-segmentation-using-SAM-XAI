# LesionDetection_3 > Yolov8DinamikCrop
https://universe.roboflow.com/lesiondetection/lesiondetection_3

Provided by a Roboflow user
License: CC BY 4.0

